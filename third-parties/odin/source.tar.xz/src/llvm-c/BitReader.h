/*===-- llvm-c/BitReader.h - BitReader Library C Interface ------*- C++ -*-===*\
|*                                                                            *|
|* Part of the LLVM Project, under the Apache License v2.0 with LLVM          *|
|* Exceptions.                                                                *|
|* See https://llvm.org/LICENSE.txt for license information.                  *|
|* SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception                    *|
|*                                                                            *|
|*===----------------------------------------------------------------------===*|
|*                                                                            *|
|* This header declares the C interface to libLLVMBitReader.a, which          *|
|* implements input of the LLVM bitcode format.                               *|
|*                                                                            *|
|* Many exotic languages can interoperate with C code but have a harder time  *|
|* with C++ due to name mangling. So in addition to C, this interface enables *|
|* tools written in such languages.                                           *|
|*                                                                            *|
\*===----------------------------------------------------------------------===*/

#ifndef LLVM_C_BITREADER_H
#define LLVM_C_BITREADER_H

#include "Deprecated.h"
#include "ExternC.h"
#include "Types.h"
#include "Visibility.h"

LLVM_C_EXTERN_C_BEGIN

/**
 * @defgroup LLVMCBitReader Bit Reader
 * @ingroup LLVMC
 *
 * @{
 */

/* Builds a module from the bitcode in the specified memory buffer, returning a
   reference to the module via the OutModule parameter. Returns 0 on success.
   Optionally returns a human-readable error message via OutMessage.

   This is deprecated. Use LLVMParseBitcode2. */
LLVM_C_ABI LLVM_ATTRIBUTE_C_DEPRECATED(
    LLVMBool LLVMParseBitcode(LLVMMemoryBufferRef MemBuf,
                              LLVMModuleRef *OutModule, char **OutMessage),
    "Use of the global context is deprecated, use LLVMParseBitcodeInContext2 "
    "instead");

/* Builds a module from the bitcode in the specified memory buffer, returning a
   reference to the module via the OutModule parameter. Returns 0 on success. */
LLVM_C_ABI LLVM_ATTRIBUTE_C_DEPRECATED(
    LLVMBool LLVMParseBitcode2(LLVMMemoryBufferRef MemBuf,
                               LLVMModuleRef *OutModule),
    "Use of the global context is deprecated, use LLVMParseBitcodeInContext2 "
    "instead");

/* This is deprecated. Use LLVMParseBitcodeInContext2. */
LLVM_C_ABI LLVMBool LLVMParseBitcodeInContext(LLVMContextRef ContextRef,
                                              LLVMMemoryBufferRef MemBuf,
                                              LLVMModuleRef *OutModule,
                                              char **OutMessage);

LLVM_C_ABI LLVMBool LLVMParseBitcodeInContext2(LLVMContextRef ContextRef,
                                               LLVMMemoryBufferRef MemBuf,
                                               LLVMModuleRef *OutModule);

/** Reads a module from the specified path, returning via the OutMP parameter
    a module provider which performs lazy deserialization. Returns 0 on success.
    Optionally returns a human-readable error message via OutMessage.
    This is deprecated. Use LLVMGetBitcodeModuleInContext2. */
LLVM_C_ABI LLVMBool LLVMGetBitcodeModuleInContext(LLVMContextRef ContextRef,
                                                  LLVMMemoryBufferRef MemBuf,
                                                  LLVMModuleRef *OutM,
                                                  char **OutMessage);

/** Reads a module from the given memory buffer, returning via the OutMP
 * parameter a module provider which performs lazy deserialization.
 *
 * Returns 0 on success.
 *
 * Takes ownership of \p MemBuf if (and only if) the module was read
 * successfully. */
LLVM_C_ABI LLVMBool LLVMGetBitcodeModuleInContext2(LLVMContextRef ContextRef,
                                                   LLVMMemoryBufferRef MemBuf,
                                                   LLVMModuleRef *OutM);

/* This is deprecated. Use LLVMGetBitcodeModule2. */
LLVM_C_ABI LLVM_ATTRIBUTE_C_DEPRECATED(
    LLVMBool LLVMGetBitcodeModule(LLVMMemoryBufferRef MemBuf,
                                  LLVMModuleRef *OutM, char **OutMessage),
    "Use of the global context is deprecated, use "
    "LLVMGetBitcodeModuleInContext2 instead");

LLVM_C_ABI LLVM_ATTRIBUTE_C_DEPRECATED(
    LLVMBool LLVMGetBitcodeModule2(LLVMMemoryBufferRef MemBuf,
                                   LLVMModuleRef *OutM),
    "Use of the global context is deprecated, use "
    "LLVMGetBitcodeModuleInContext2 instead");

/**
 * @}
 */

LLVM_C_EXTERN_C_END

#endif
