use crate::{
    BinaryReader, ComponentExternalKind, ComponentValType, FromReader, Result, SectionLimited,
};
use alloc::borrow::Cow;

/// Represents the type bounds for imports and exports.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum TypeBounds {
    /// The type is bounded by equality.
    Eq(u32),
    /// A fresh resource type,
    SubResource,
}

impl<'a> FromReader<'a> for TypeBounds {
    fn from_reader(reader: &mut BinaryReader<'a>) -> Result<Self> {
        Ok(match reader.read_u8()? {
            0x00 => TypeBounds::Eq(reader.read()?),
            0x01 => TypeBounds::SubResource,
            x => return reader.invalid_leading_byte(x, "type bound"),
        })
    }
}

/// Represents a reference to a component type.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ComponentTypeRef {
    /// The reference is to a core module type.
    ///
    /// The index is expected to be core type index to a core module type.
    Module(u32),
    /// The reference is to a function type.
    ///
    /// The index is expected to be a type index to a function type.
    Func(u32),
    /// The reference is to a value type.
    Value(ComponentValType),
    /// The reference is to a bounded type.
    ///
    /// The index is expected to be a type index.
    Type(TypeBounds),
    /// The reference is to an instance type.
    ///
    /// The index is a type index to an instance type.
    Instance(u32),
    /// The reference is to a component type.
    ///
    /// The index is a type index to a component type.
    Component(u32),
}

impl ComponentTypeRef {
    /// Returns the corresponding [`ComponentExternalKind`] for this reference.
    pub fn kind(&self) -> ComponentExternalKind {
        match self {
            ComponentTypeRef::Module(_) => ComponentExternalKind::Module,
            ComponentTypeRef::Func(_) => ComponentExternalKind::Func,
            ComponentTypeRef::Value(_) => ComponentExternalKind::Value,
            ComponentTypeRef::Type(..) => ComponentExternalKind::Type,
            ComponentTypeRef::Instance(_) => ComponentExternalKind::Instance,
            ComponentTypeRef::Component(_) => ComponentExternalKind::Component,
        }
    }
}

impl<'a> FromReader<'a> for ComponentTypeRef {
    fn from_reader(reader: &mut BinaryReader<'a>) -> Result<Self> {
        Ok(match reader.read()? {
            ComponentExternalKind::Module => ComponentTypeRef::Module(reader.read()?),
            ComponentExternalKind::Func => ComponentTypeRef::Func(reader.read_var_u32()?),
            ComponentExternalKind::Value => ComponentTypeRef::Value(reader.read()?),
            ComponentExternalKind::Type => ComponentTypeRef::Type(reader.read()?),
            ComponentExternalKind::Instance => ComponentTypeRef::Instance(reader.read()?),
            ComponentExternalKind::Component => ComponentTypeRef::Component(reader.read()?),
        })
    }
}

/// Represents an import in a WebAssembly component
#[derive(Debug, Copy, Clone, Eq, PartialEq)]
pub struct ComponentImport<'a> {
    /// The name of the imported item.
    pub name: ComponentExternName<'a>,
    /// The type reference for the import.
    pub ty: ComponentTypeRef,
}

impl<'a> FromReader<'a> for ComponentImport<'a> {
    fn from_reader(reader: &mut BinaryReader<'a>) -> Result<Self> {
        Ok(ComponentImport {
            name: reader.read()?,
            ty: reader.read()?,
        })
    }
}

/// A reader for the import section of a WebAssembly component.
///
/// # Examples
///
/// ```
/// use wasmparser::{ComponentImportSectionReader, BinaryReader};
/// let data: &[u8] = &[0x01, 0x00, 0x01, 0x41, 0x01, 0x66];
/// let reader = BinaryReader::new(data, 0);
/// let reader = ComponentImportSectionReader::new(reader).unwrap();
/// for import in reader {
///     let import = import.expect("import");
///     println!("Import: {:?}", import);
/// }
/// ```
pub type ComponentImportSectionReader<'a> = SectionLimited<'a, ComponentImport<'a>>;

/// Represents the name of a component import.
#[derive(Debug, Copy, Clone, Eq, PartialEq)]
#[allow(missing_docs)]
pub struct ComponentExternName<'a> {
    pub name: &'a str,
    pub implements: Option<&'a str>,
    pub version_suffix: Option<&'a str>,
    pub external_id: Option<&'a str>,
}

impl<'a> ComponentExternName<'a> {
    /// Returns the full name of this import or export, which is `name` with
    /// the `version_suffix` appended if it applies to `name`.
    ///
    /// For example `a:b/c@0.2` with a version suffix of `.1` has a full name of
    /// `a:b/c@0.2.1`. If `implements` is specified then the version suffix
    /// applies to the implements instead, and `name` is returned as-is. See
    /// [`ComponentExternName::full_implements`].
    pub fn full_name(&self) -> Cow<'a, str> {
        match self.implements {
            Some(_) => Cow::Borrowed(self.name),
            None => with_version_suffix(self.name, self.version_suffix),
        }
    }

    /// Returns the full name of the interface in `implements`, if specified,
    /// which is `implements` with the `version_suffix` appended.
    ///
    /// For example `(implements "a:b/c@1")` with a version suffix of `.2.3`
    /// has a full name of `a:b/c@1.2.3`.
    pub fn full_implements(&self) -> Option<Cow<'a, str>> {
        Some(with_version_suffix(self.implements?, self.version_suffix))
    }
}

/// Appends `version_suffix` to `name` if it's an interface name with a
/// version, such as `a:b/c@0.2`, and otherwise returns `name` as-is.
pub(crate) fn with_version_suffix<'a>(name: &'a str, version_suffix: Option<&str>) -> Cow<'a, str> {
    use crate::prelude::ToString;
    match version_suffix {
        Some(suffix) if name.contains('@') => Cow::Owned(name.to_string() + suffix),
        _ => Cow::Borrowed(name),
    }
}

impl<'a> FromReader<'a> for ComponentExternName<'a> {
    fn from_reader(reader: &mut BinaryReader<'a>) -> Result<Self> {
        let has_options = match reader.read_u8()? {
            // This is the spec-required byte as of this time.
            0x00 => false,

            // Prior to WebAssembly/component-model#263 export names used a
            // discriminator byte of 0x01 to indicate an "interface" of the
            // form `a:b/c` but nowadays that's inferred from string syntax.
            // Ignore 0-vs-1 to continue to parse older binaries. Eventually
            // this will go away.
            //
            // This logic to ignore 0x01 was landed on 2023-10-28 in
            // bytecodealliance/wasm-tools#1262 and the encoder at the time
            // still emitted 0x01 to have better compatibility with prior
            // validators.
            //
            // On 2024-09-03 in bytecodealliance/wasm-tools#TODO the encoder
            // was updated to always emit 0x00 as a leading byte. After enough
            // time has passed this case may be able to be removed. When
            // removing this it's probably best to do it with a `WasmFeatures`
            // flag first to ensure there's an opt-in way of fixing things.
            0x01 => false,

            0x02 => {
                if reader.cm_implements() || reader.cm_canon_names() {
                    true
                } else {
                    bail!(
                        reader.original_position() - 1,
                        "the `cm-implements` feature is not active"
                    )
                }
            }

            x => return reader.invalid_leading_byte(x, "component name"),
        };
        let mut ret = ComponentExternName {
            name: reader.read_string()?,
            implements: None,
            version_suffix: None,
            external_id: None,
        };
        if has_options {
            for _ in 0..reader.read_var_u32()? {
                let pos = reader.original_position();
                match reader.read()? {
                    ComponentNameOpt::Implements(name) => {
                        if ret.implements.is_some() {
                            bail!(pos, "duplicate 'implements' option in name");
                        }
                        ret.implements = Some(name);
                    }
                    ComponentNameOpt::VersionSuffix(name) => {
                        if ret.version_suffix.is_some() {
                            bail!(pos, "duplicate 'version-suffix' option in name");
                        }
                        ret.version_suffix = Some(name);
                    }
                    ComponentNameOpt::ExternalId(name) => {
                        if ret.external_id.is_some() {
                            bail!(pos, "duplicate 'external-id' option in name");
                        }
                        ret.external_id = Some(name);
                    }
                }
            }
        }
        Ok(ret)
    }
}

enum ComponentNameOpt<'a> {
    Implements(&'a str),
    VersionSuffix(&'a str),
    ExternalId(&'a str),
}

impl<'a> FromReader<'a> for ComponentNameOpt<'a> {
    fn from_reader(reader: &mut BinaryReader<'a>) -> Result<Self> {
        match reader.read_u8()? {
            0x00 => Ok(ComponentNameOpt::Implements(reader.read()?)),
            0x01 => Ok(ComponentNameOpt::VersionSuffix(reader.read()?)),
            0x02 => Ok(ComponentNameOpt::ExternalId(reader.read()?)),
            x => return reader.invalid_leading_byte(x, "name option"),
        }
    }
}
