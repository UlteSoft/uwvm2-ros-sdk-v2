
# Clear the LD_LIBRARY_PATH if GNUstep set it so that we don't accidentally use
# the installed version


set(INCREMENTAL " ")
if (MSVC)
	set(CMAKE_EXE_LINKER_FLAGS "/DEBUG /INCREMENTAL:NO ${CMAKE_EXE_LINKER_FLAGS}")
	set(INCREMENTAL "/INCREMENTAL:NO")
endif ()

# List of single-file tests.
set(TESTS
	alias.m
	alignTest.m
	bitfield.m
	AllocatePair.m
	AssociatedObject.m
	AssociatedObject2.m
	BlockCapture_arc.m
	BlockTest_arc.m
	ConstantString.m
	Category.m
	ExceptionTest.m
	FastARC.m
	FastARCPool.m
	FastRefCount.m
	Forward.m
	ManyManySelectors.m
	NestedExceptions.m
	PropertyAttributeTest.m
	ProtocolExtendedProperties.m
	PropertyIntrospectionTest.m
	ProtocolCreation.m
	ResurrectInDealloc_arc.m
	RuntimeTest.m
	SuperMethodMissing.m
	WeakBlock_arc.m
	WeakRefLoad.m
	WeakReferences_arc.m
	WeakImportClass.m
	ivar_arc.m
	ivar_atomic.m
	IVarOverlap.m
	IVarSuperclassOverlap.m
	objc_msgSend.m
	NilTypeQualifier.m
	msgInterpose.m
	NilException.m
	MethodArguments.m
	zeroSizedIVar.m
	exchange.m
	hash_table_delete.c
	hash_test.c
	setSuperclass.m
	UnexpectedException.m
)

if (EMBEDDED_BLOCKS_RUNTIME)
	list(APPEND TESTS BlockImpTest.m)
endif()

set(ENABLE_ALL_OBJC_ARC_TESTS On)

if (WIN32)
	# On Windows these tests work only with more recent versions of Clang
	set(ENABLE_ALL_OBJC_ARC_TESTS Off)
	if (CMAKE_C_COMPILER_ID STREQUAL Clang)
		if (CMAKE_C_COMPILER_VERSION VERSION_GREATER_EQUAL 16.0.0)
			set(ENABLE_ALL_OBJC_ARC_TESTS On)
		endif()
	endif()

	if (CMAKE_SYSTEM_PROCESSOR STREQUAL ARM64)
		list(APPEND TESTS
			objc_msgSend_WoA64.mm
		)
	endif()
else ()
	# Don't run the tests that are specific to Itanium-style exceptions on
	# Windows.
	list(APPEND TESTS
	BoxedForeignException.m
	ForeignException.m
	)
endif ()

if (ENABLE_ALL_OBJC_ARC_TESTS)
	list(APPEND TESTS
	ARCTest_arc.m
	PropertyIntrospectionTest2_arc.m
	)
endif()

# List of single-file tests that won't work with the legacy ABI and so
# shouldn't be run in legacy mode.
set(NEW_TESTS
	category_properties.m
	DirectMethods.m
	FastPathAlloc.m
)

remove_definitions(-D__OBJC_RUNTIME_INTERNAL__=1)

add_library(test_runtime_legacy OBJECT Test.m)
set_target_properties(test_runtime_legacy PROPERTIES
	INCLUDE_DIRECTORIES "${CMAKE_SOURCE_DIR};${PROJECT_BINARY_DIR}/objc/"
	COMPILE_FLAGS "-Xclang -fblocks -fobjc-runtime=gnustep-1.7"
	LINKER_LANGUAGE C
)

add_library(test_runtime OBJECT Test.m)
set_target_properties(test_runtime PROPERTIES
	INCLUDE_DIRECTORIES "${CMAKE_SOURCE_DIR};${PROJECT_BINARY_DIR}/objc/"
	COMPILE_FLAGS "-Xclang -fblocks -fobjc-runtime=gnustep-2.0"
	LINKER_LANGUAGE C
)


# Function for adding a test.  This takes the name of the test and the list of
# source files as arguments.
function(addtest_flags TEST_NAME FLAGS TEST_SOURCE LINK_TARGET EXTRA_LINK_FLAGS)
	if (${TEST_NAME} MATCHES ".*_arc")
		# Only compile the main file with ARC
		set_source_files_properties(${TEST_SOURCE}
			COMPILE_FLAGS "-Xclang -fobjc-arc")
	endif()
	add_executable(${TEST_NAME} ${TEST_SOURCE})
	add_test(${TEST_NAME} ${TEST_NAME})
	set(ARC "")
	set_target_properties(${TEST_NAME} PROPERTIES
		INCLUDE_DIRECTORIES "${CMAKE_SOURCE_DIR};${PROJECT_BINARY_DIR}/objc/"
		COMPILE_FLAGS "-Xclang -fblocks -Xclang -fobjc-exceptions ${FLAGS}"
		LINK_FLAGS "${INCREMENTAL} ${EXTRA_LINK_FLAGS}"
		LINKER_LANGUAGE C
	)
	set_property(TEST ${TEST_NAME} PROPERTY SKIP_RETURN_CODE 77)
	set_property(TEST ${TEST_NAME} PROPERTY
		ENVIRONMENT "LD_LIBRARY_PATH=" "LLVM_PROFILE_FILE=${TEST_NAME}.profraw"
	)
	if(WIN32)
		set_property(TEST ${TEST_NAME} PROPERTY ENVIRONMENT_MODIFICATION "PATH=path_list_append:${CMAKE_BINARY_DIR}")
	endif()
	target_link_libraries(${TEST_NAME} ${LINK_TARGET})
endfunction(addtest_flags)

function(addtest_variants_for_target TEST TEST_SOURCE LEGACY LINK_TARGET SUFFIX EXTRA_LINK_FLAGS)
	addtest_flags("${TEST}${SUFFIX}" "-O0 -fobjc-runtime=gnustep-2.2 -UNDEBUG -DGS_RUNTIME_V2" "${TEST_SOURCE}" ${LINK_TARGET} "${EXTRA_LINK_FLAGS}")
	target_sources("${TEST}${SUFFIX}" PRIVATE $<TARGET_OBJECTS:test_runtime>)
	addtest_flags("${TEST}_optimised${SUFFIX}" "-O3 -fobjc-runtime=gnustep-2.2 -UNDEBUG -DGS_RUNTIME_V2" "${TEST_SOURCE}" ${LINK_TARGET} "${EXTRA_LINK_FLAGS}")
	target_sources("${TEST}_optimised${SUFFIX}" PRIVATE $<TARGET_OBJECTS:test_runtime>)

	# -fobjc-arc is not supported on platforms using the legacy runtime
	if (${LEGACY} AND ${OLDABI_COMPAT} AND NOT ${TEST} MATCHES ".*_arc")
		addtest_flags("${TEST}_legacy${SUFFIX}" "-O0 -fobjc-runtime=gnustep-1.7 -UNDEBUG" "${TEST_SOURCE}" ${LINK_TARGET} "${EXTRA_LINK_FLAGS}")
		target_sources("${TEST}_legacy${SUFFIX}" PRIVATE $<TARGET_OBJECTS:test_runtime_legacy>)
		addtest_flags("${TEST}_legacy_optimised${SUFFIX}" "-O3 -fobjc-runtime=gnustep-1.7 -UNDEBUG" "${TEST_SOURCE}" ${LINK_TARGET} "${EXTRA_LINK_FLAGS}")
		target_sources("${TEST}_legacy_optimised${SUFFIX}" PRIVATE $<TARGET_OBJECTS:test_runtime_legacy>)
	endif()
endfunction(addtest_variants_for_target)

function(addtest_variants TEST TEST_SOURCE LEGACY)
	addtest_variants_for_target(${TEST} "${TEST_SOURCE}" ${LEGACY} objc "" "")
	if (BUILD_STATIC_LIBOBJC)
		addtest_variants_for_target(${TEST} "${TEST_SOURCE}" false objc-static "_static" "-static")
	endif()
endfunction(addtest_variants)

foreach(TEST_SOURCE ${TESTS})
	get_filename_component(TEST ${TEST_SOURCE} NAME_WE)
	addtest_variants(${TEST} ${TEST_SOURCE} true)
endforeach()

foreach(TEST_SOURCE ${NEW_TESTS})
	get_filename_component(TEST ${TEST_SOURCE} NAME_WE)
	addtest_variants(${TEST} ${TEST_SOURCE} false)
endforeach()

# Tests that are more than a single file.
addtest_variants("CXXExceptions" "CXXException.m;CXXException.cc" true)
addtest_variants("ForwardDeclareProtocolAccess" "ForwardDeclareProtocolAccess.m;ForwardDeclareProtocol.m" true)
if (ENABLE_OBJCXX)
	addtest_variants(ObjCXXEHInterop "ObjCXXEHInterop.mm;ObjCXXEHInterop.m" true)
	addtest_variants(ObjCXXEHInteropTwice "ObjCXXEHInteropTwice.mm" true)
	if (WIN32 AND CMAKE_CXX_COMPILER_ID STREQUAL Clang)
		if (CMAKE_CXX_COMPILER_VERSION VERSION_GREATER_EQUAL 16.0.0)
			addtest_variants(ObjCXXEHInterop_arc "ObjCXXEHInterop_arc.mm;ObjCXXEHInterop_arc.m" true)
		endif()
	else()
		addtest_variants(ObjCXXEHInterop_arc "ObjCXXEHInterop_arc.mm;ObjCXXEHInterop_arc.m" true)
	endif()
endif()

# Some tests use enough memory that they fail on CI intermittently if they
# happen to run in parallel with each other.
set_tests_properties(ManyManySelectors PROPERTIES PROCESSORS 3)
set_tests_properties(ManyManySelectors_optimised PROPERTIES PROCESSORS 3)
if (${LEGACY})
	set_tests_properties(ManyManySelectors_legacy PROPERTIES PROCESSORS 3)
	set_tests_properties(ManyManySelectors_legacy_optimised PROPERTIES PROCESSORS 3)
endif ()
if (BUILD_STATIC_LIBOBJC)
	set_tests_properties(ManyManySelectors_static PROPERTIES PROCESSORS 3)
	set_tests_properties(ManyManySelectors_optimised_static PROPERTIES PROCESSORS 3)
endif ()
